*****************
 NodeUtil Readme
*****************
NodeUtil 3.53
1. NDU-191 - Fixed a problem with the address table count in certain cases (byte swapping problem).

NodeUtil 3.52
1. NDU-172 - Need to be more selective about buffer re-configuration.

NodeUtil 3.51
1. NDU-183 - tweak fix in 3.49 to better handle address table and mtag counts in host nodes.

NodeUtil 3.50
1. NDU-184 - work with slow flash chip erase times (BL6050V4)

NodeUtil 3.49
1. Precedence is now given to address table counts in SNVT capability info over the read only data structure.

NodeUtil 3.48
1. Fixed a problem with the 'x' command (make a xif).  Node with Extended Address Table entries not handled right.

NodeUtil 3.47
1. Fixed a problem with the 'x' command (make a xif).  Comm parameters wrong for standard transceivers.

NodeUtil 3.46
1. Suppress symbol table warnings for non-expert users

NodeUtil 3.45
1. Fixed cases where error messages were not always getting printed clearly

NodeUtil 3.44
1. 'd' command: Add ability to specify random bytes in domain ID (using %r)

NodeUtil 3.43
1. Fix NDU-174 - Alias table fails for node with 4096 NVs

NodeUtil 3.42
1. Port to Linux.  Note that on these platforms NodeUtil must have exclusive access to the network interface.
   There is no NI sharing like there is on the PC with the LNS/VNI facility.

NodeUtil 3.41
1. Fixed a couple minor NI domain management issues
2. Fixed major regression in 3.40 w.r.t. system image downloading of 6050 style devices.

NodeUtil 3.40
1. Add verbose option for keeping application message statistics.

NodeUtil 3.39
1. Fix bug where Model 0 (3150) was mistaken for 6050 loading. This prevented 3150 NDL files from being loaded.

NodeUtil 3.38
1. Fix bug where insufficient data prompt kept recurring for right padding even if not wanted.
2. Fix formatting bug in read memory output introduced in previous build.

NodeUtil 3.37
1. Fix incorrect conversion of time between iterations for scripts
2. Fix crash that could occur under certain anomalous '[' command scenarios.
3. Allow escape from the file name prompt when using the 'l' command in the node menu.
4. Add support for PL 3170.
5. SLB no longer reports itself as "halted"
6. Fix crash that occurred when reading/writing SLB memory.
7. Fix incorrect handling of wait time in script files.
8. Send reset requests on both primary and secondary channel (benefits PLC communications).
9. Add ability to specify a NID in a request.  If you use @<n> in a request, it gets converted to the Nth NID in the list.  
   For a '[' or ']' command, @@ means the next NID in the list.  For example, if you have nodes 1, 2, 3 and 4 with 
   NIDs A, B, C and D and go to node 2 and say 

   [
   6
   0
   q
   3
   10
   n
   4d
   00cc4b @@ 51

   then this would substitute in A, C, D, A, C, D.

NodeUtil 3.36
1. Modify list ('l') command output to match Neuron C syntax.
2. Added NM authentication to device options ('o') command.
3. Device Status ('s') command now shows if a node is halted in the debugger by appending " ( Halted)" to the "Device state" output.
4. Buffer re-configuration is not allowed on nodes with based firmware version V22 or higher.
5. Add '+' command that loads application symbols from a .MAP file (helps with disassembly output).
6. Automatically load application symbols using '+' mechanism when downloading an application.
7. When using -b on a non-OMA interface (e.g., U10), NodeUtil would erroneously complain
   about the use of OMA on a non-OMA interface.  This should no longer happen.
8. The algorithm for setting big output buffers during download has been improved to 
   attempt to also keep big network input buffers (for benefit of LonScanner).  However,
   this will usually not really help.  Best bet is to configure the buffer configuration
   by hand to have both big in and out buffers in which case NodeUtil won't change it.

NodeUtil 3.35
1. Correct XIF generation for nodes with >62 NVs
2. Correct XIF generation for NV definitions.
3. Improve XIF generation comm parameter output.
4. IUP now supports system images (standalone), DSP & bootloader.
5. 's' command to node 0 no longer prints warning for non-IP interfaces.
6. Fixed bug where 'q' command did not work for node 0.
7. Initially use new expanded query NV/Alias config commands, and fall back to legacy commands when not supported.

NodeUtil 3.34
1. Add NIU option for IUP including LTD digest
2. IUP supports system images (standalone), DSP, bootloader
3. Allow up to 228 bytes of data in the Q command
4. "(Q)uickly send a message" command displayed the *last* data length. Now displays the current data length
5. Add check for newer versions available (Echelon internal network only)

NodeUtil 3.32
1. Extended '$' command to work with addresses greater than 0xFFFF.

NodeUtil 3.31
1. Improved way comments ('#') are handled.
2. Changed '#' command added in 3.28 to '$' (since it prevented comments)
3. Make some various improvements to IUP.

NodeUtil 3.30
1. Added ']' command that is like '[' except that it can also validate responses.
2. Added support for escape in request or response data as follows:
   a. %1 - 8-bit node number
   b. %2 - 6-byte MAC ID
   c. %3 - 8-bit node number or-ed with 0x80 

NodeUtil 3.29
1. Fixed problem where one was allowed to load BL60x0V4.NDL into a node that it would not work for (NDU-123).

NodeUtil 3.28
1. Fixed more instances of where a "too long" response could corrupt the stack.
2. Fixed problem with '[' command in main menu when mixed with 'g' 0.
3. Add node menu '#' command to read memory using any mode including stats relative, config relative and flash relative.

NodeUtil 3.27
1. Add 'c' command to main menu that clears device list.
2. Add '[' command to main menu that operates on all devices.
3. Fix problem where a "too long" response could corrupt the stack.

NodeUtil 3.26
1. There is a new option for the device menu 'm' command (as in "Change device (M)ode or state").  
   That option is "(P)hysical reset".  This will force a hard reset of the device (on some devices 
   the "(R)eset" command only resets the LonTalk stack and not the whole device).

NodeUtil 3.25
1. Update the list of SNVT types to match the SNVT master list as of 3/25/2015.
2. Allow user to specify IUP spacing interval.

NodeUtil 3.24
1. Allow downloading system images with version >= to the minimum version specified in the NDL.
2. Fix various issues with IUP support.
3. Properly render RSSI and LQI for RF devices.
4. Use legacy commands to update NV and alias config if address index is set to "none".

NodeUtil 3.23
1. Support for loading blank 6010s.
2. Add support for the Image Update Protocol (IUP).

NodeUtil 3.22
1. Updates to load process for NodeLoad 2.10 6010 support.

NodeUtil 3.21
1. Clear clone domain when setting the device address via the '!' command.

NodeUtil 3.20
1. Fix bug in 'o' command to properly set or clear advanced options when domain.invalid is set but len != 7.
2. Support loading write protected application images

NodeUtil 3.19
1. Update '!' command to support clearing the IP address.  When domain is invalid, display IP address as 0.0.0.0
2. Add verbose option to control whether UDP packets are displayed or not.  Disabled by default.  If enabled, decompress UDP header.

NodeUtil 3.18
1. Correctly detect when NM authentication is required

NodeUtil 3.16
-------------
1. System image download no longer asks if you want to download comm parameters.  It just does it.  
   However, if the comm parameters are incompatible, it asks if you want to do it anyway.
2. Mode 5 (RAM only) writes to FLASH address space in the Neuron now available.
3. New copyright notice.
4. Neuron-based routers now properly handled.

NodeUtil 3.15
-------------
1. Switch to enhanced mode when talking to a FT 6010.

NodeUtil 3.14
-------------
1. Add '!' command for showing IP address.

NodeUtil 3.13
-------------
1. Handle transition of Neuron ID to MAC ID when going from V19/V125 to V21.

NodeUtil 3.12
-------------
1. Support the downloading of a flash bootloader into the FT 6000 series.

NodeUtil 3.11
-------------
1. Add support for LonTalk/IP Enhanced Mode.

NodeUtil 3.10
-------------
1. Rebuild with support for the FT 6000 series in NodeLoad.

NodeUtil 3.09
-------------
1. Properly handle tabs in data input as whitespace (as might occur in scripts).

NodeUtil 3.08
-------------
1. Updated the model numbers to include a variety of non-Neuron devices.
2. Show the version numbers, 0 or otherwise, if provided in the get full version response.
3. Allow comments ("#") in scripts.
4. If the first line of a NodeUtil script starts with #!, then this line determines 
   the count and wait parameters rather than prompting.  The default is one iteration.  
   If you want to specify iterations more than 1, then use "count=<iterations>".  
   -1 means forever.  The time to wait in seconds between iterations is specified 
   via "wait=<seconds>".  If not specified, 0 is used.  For example, to have the script 
   run 5 times with 3 seconds between runs, use "#! count=5 wait=3.
5. Print warning about idle network requirement if FT 6050 access fails.
6. Check for FT 6050 regardless of the EEPROM state.
7. -Z switch is honored.  This way if you have two instances on the same NI, they won't conflict if 
   you specify unique domains.
8. Disassembly output and read/write memory now use symbol table.

NodeUtil 3.07
-------------
1. Fixed clock command for FT 60x0
2. System image download now updates comm parameters

NodeUtil 3.06
-------------
1. Support for downloading system image NDLs into a FT 60x0 (with erased flash)

NodeUtil 3.05
-------------
1. Add support for minor version and build number

NodeUtil 3.04
-------------
1. Add support for FT 60x0

NodeUtil 3.03
-------------
1. Support system image NDL loading into flash at addresses >0xFFFF.
2. When entering NV values, if the input is too short, ask how to pad it (left/right).

NodeUtil 3.02
-------------
1. Disassembly no longer uses relative addressing for branches.
2. Added some more new Neuron error log codes.
3. Added support for NDL files with memory beyond 0xFFFF.

NodeUtil 3.01
-------------
1. Added some new Neuron error log codes.
2. Added new statistic for lost messages due to lack of extension buffer.

NodeUtil 3.00
-------------
1. Modified to build with MSVC 2008.
2. Eliminated distinctions between NodeWiz and NodeUtil.

NodeWiz 2.35
------------
1. Now runs on Linux.

NodeWiz 2.34
------------
1. Reduce time nodewiz spends sleeping 
2. Make prompt for message code a byte fetch
3. Make iteration counter in '[' command 32-bits (so -1 is a long test)
4. Default nodewiz's NV selectors to unbound values
5. Fix crash that could occur under lots of traffic

NodeWiz 2.33
------------
1. Display a unique error if the protocol stack drops the response due to it being considered
invalid (this can happen with certain versions of LNS when the response code falls in the
NM/ND space of 0x50-0x7F).  You can workaround this by using nodewiz with the -B option.

NodeWiz 2.32
------------
1. Fix crash when accessing device with bogus application structures.
2. Enable downloading of system images to FT5000.
3. Use big buffers when downloading an FT5000.
4. Adjust buffer size during download after the read only data structure takes effect (in
case new buffer size is smaller than old).

NodeWiz 2.31
------------
1. Fix bug in nv config update command that occurred with address table
indices >0.

NodeWiz 2.30
------------
1. Fix bug in alias update command that occurred with address table
indices >0.

NodeWiz 2.29
------------
1. Add 'X' command to main menu that finds an unconfigured device and 
goes to it.
2. Add warning if a MIP fails to respond to SNVT queries and optionally
activate -J command line option.

NodeWiz 2.28
------------
1. If the "-$" option is specified on the command line, then secure devices will be
   forced to the nascent state to gain access (currently only works for PCC devices).
2. In some cases the key printed by the 'g' or 'l' command would be garbage.
3. Unlock eeprom prior to updating a domain structure using 'd'.

NodeWiz 2.27
------------
1. If the transceiver ID is "unknown", assume a slow (power line) channel for timing purposes.

NodeWiz 2.26
------------
1. Fix bug that caused nodewiz to use authentication unnecessarily (performance impact only).

NodeWiz 2.25
------------
1. '<' command remembers last file name used.
2. 'q' (main menu) command no longer will create an entry for a duplicate ID.
3. When using authentication, automatically try the nascent key before prompting (nodewiz only).
4. After download, resync authentication in case node self-installs as authenticated.
5. When updating auth key via 'd' (device menu) command, also update local key
6. Unlock eeprom before write memory (with checksum update), download and state change.

NodeWiz 2.24
------------
1. Modified and updated support for the extended address table.

NodeWiz 2.23
------------
1. On a 'y' (download) failure, always release the download file
2. Improve performance of download by using larger packet sizes in more cases
3. Add more text about buffer configuration as it applies to appless nodes
4. Fix verbose option
5. Add a tx timer option to the '[' (performance) command
6. Add warning about communication failures possibly being due to clone domain configuration
7. Get NI status in more places so that OMA warning is only shown when it really needs to be
8. Use registry for the LonWorks path
9. Fix router far side communications (broken since 2.18)

NodeWiz 2.22
------------
1. Add support for Extended Address Tables

NodeWiz 2.21
------------
1. Change input and output commands to '<' and '>' respectively and make both available in all menus.
2. Make all nodewiz features except disassembly and VNI available to nodeutil
3. Fix some bugs in alias and NV table editing and display
4. Allow domains to be set as clone domains
5. Allow key to be set even if domain is unused

NodeWiz 2.20
------------
1. Better handle checksum update failures during download.
2. Show histogram of responses when using '[' command.

NodeWiz 2.19
------------
1. Fix bug in the "*" (refresh) command.  It was not working properly for 3150s.
2. Allow 0 for "[" command iteration count to mean indefinite.
3. Hitting a key during "[" terminates it.
4. Show date/time during "[".
5. Show iteration counter during "[".
6. Using cmd.exe rather than command.com for the "z" command.

NodeWiz 2.18
------------
1. Fix bug introduced in 2.08 that caused domain index to be ignored
   when handling an address table update ('a' command)
2. Make terminology more consistent (use device rather than node)
3. Add a 'q' command that adds a Neuron ID without to the device list
   without trying to communicate with it.
4. Make download more tolerant of nodes that take a long time to compute a 
   checksum.

NodeWiz 2.17
------------
1. Completed FT5000 XCVR/Clock modification ('t' command)
2. FT3200 changed to FT5000.
3. Make reason for "c" node command failure more evident.

NodeWiz 2.16
------------
1. Support for SLB model
2. Support for build numbers
3. Better rendering of custom firmware versions
4. Added transceiver status info to device "t" command
5. Fixed bug with "t" command and authenticated devices

Nodewiz 2.15
------------
1. Flush output stream ('o' command) on every write.
2. Don't require a key to be hit after processing the -i command line option.

Nodewiz 2.14
------------
1. Add -J option to NodeWiz help output
2. Add a retry count query to the performance test command ('[')

Nodewiz 2.13
------------
1. Recognize FT3200 model numbers.
2. FT3200 comm/clock rate translations. Use either "external" or "system" clock wording based on model number.
3. FT3200 download allows the system clock setting to change.
4. Added latest System Errors to reporting (up to 178).

NodeWiz 2.10 
------------
1. Make the "verify" command somewhat faster
2. Add a refresh command "*" that refreshes the device's checksummed memory
3. Make the download process check for spurious resets during the load process and fail if they occur
4. Add a "J" switch to the command line that causes host queries to be skipped when process MIPs.  This
   can be used to speed up node menu entry or download when dealing with MIPs which have no host attached 
   (since they would otherwise time out trying to fetch SI data and the like).

NodeWiz 2.08
------------
1. Add support SI version 2.
2. Add support for ECS (Extended Command Set) Nodes.

NodeWiz 2.07
------------
1. ATM discovery now shows margin and signal strength for return path.
2. Maximum NV size increased from 31 to 227 bytes.

NodeWiz 2.06
------------
1. Don't allow OMA setting for older network interfaces.
2. Don't expect bidirectional signal strength data for older network interfaces.
3. Program ID model number is now interpreted just as a number (was shown as Neuron model).
4. Nodewiz now allows download of communication parameters when downloading NDL files.

NodeWiz 2.05
------------
1. Miscellaneous tweaks to ATM.
2. Don't show NV fixed table for host nodes.
3. Changed PLT-22 comm parameters to allow secondary frequency (no longer PLT-21 compatible).
4. Added support for alias indices beyond 255.

NodeWiz 2.04
------------
1. Add missing lines in generated XIF header.
2. Print warning if NDL file given to Chec(k) command.
3. Mask out certain control bits from special purpose mode comm parameter
   type byte during comm parameter validation (NodeLoad).
4. Use registry to get location of LonWorks directory.
5. Allow Chec(k) command to be aborted.
6. Honor <esc> after prompting for download file name.

NodeWiz 2.03
------------
1. Added '2' command to general menu.  It does ATM discovery.  It is a one shot
   query and thus is by no means guaranteed to find all devices.  If you have
   lots of devices, good chance it won't work at all.  But, it could be useful
   if you have only a few devices.  Also, it doesn't "add" the discovered
   devices, you have to do that by hand.
2. If you add a device and it fails authentication, then it will ask for a key.
   It uses that key whenever you 'g' to that device.  
3. If adding a device fails to communicate or fails authentication, it still 
   adds it and you can still go to the node and at least do some query status 
   and query signal strength commands.
4. If you go to a device, you can use the '=' command to get signal strength
   data.  It gets the data for both frequencies.

NodeWiz 2.02
------------
1. Now use stdxcvr.xml to map transceiver IDs to names.
2. Fixed crash that occurred when a node had no self identification data.

NodeWiz 2.01
------------
1. File names entered at console prompts now allow spaces in the file name (name
   can be quoted or not).  This does not apply to file names specified on the command line.

NodeWiz 2.00
------------
1. When download fails due to version or model mismatch, provide a message to that effect.
2. When invoking node 'C' command, refresh the cached data from the device first.
3. When stopped in paged output mode, allow an escape key to abort the output.
4. Properly handle the new Version 16 firmware read only data structure.
5. Use common directories for VNI files.

NodeWiz 1.97
------------
1. Show F1 in help menu.
2. Take device offline before starting download.
3. Disallow reboot of non-3150 devices.

NodeWiz 1.96
------------
1. Don't resize the window when starting up.
2. Don't set the priority buffer counts to 0 when automatically resizing buffers.

NodeWiz 1.95
------------
1. Fix some problems with domain modifications introduced by OMA support (1.86).
2. If you hit the F1 key at a main prompt, you get the version information.

NodeWiz 1.94
------------
1. Don't attempt to read extended read only data from nodes with a base version less than 16.

NodeWiz 1.93
------------
1. Allow 'Q' command to send authenticated messages.

NodeWiz 1.92
------------
1. Added support for Version 16 firmware including new read only data structure format
and new event table format.
2. Fixed a bug where messaging failures during disassembly output could cause a crash. 
3. Allow escape out of node 'C' command.

NodeWiz 1.91
------------
1. 1.90 was erroneously treating NXEs as NDL files. 

NodeWiz 1.90
------------
1. Big buffer reset was not being used for 3150s.

NodeWiz 1.89
------------

1. Fixed crash when doing an 'N' command with an NV count that doesn't match the node's actual count.  
   This could occur with a misconfigured ShortStack host, for example.
2. Reject hexadecimal numbers with more than 4 characters.
3. Reduced initial buffer size used for loading 3150 applications.
4. Fixed corruptions that could occur with very long file names (more than 80 characters).

NodeWiz 1.88
------------

1. Fixed crash when directing output to a file via the "O" command when the file already existed.
2. Fixed big buffer reset problem when loading older 3120s via the "Y" command.
3. Added -H switch which bypasses network interface configuration (unless it's unconfigured).  This
   was done primarily for the benefit of nodeload which will be used by the minikit now. (This is not
   available in NodeUtil).

NodeWiz 1.87
------------

1. Fixed problem with reading escaped alias count in the SI data.
2. Added support for the latest Neuron Chip models.
3. Fixed problems with alias display.  Also, added ability to clear an alias entry.
4. Fixed bug in NV entry update command.

NodeWiz 1.86
------------

1. Added a command, '[', to the node menu that allows you to send a message N times with a spacing of D.
   (This is not available in NodeUtil).
2. Removed warning about buffer configuration with Layer 2 MIPs since VNIs now handle this correctly.

NodeWiz 1.84
------------

1. Increase re-transmit timer for power line transactions to 1.5 seconds
2. Added "-b" switch that suppresses use of VNI
3. Changed buffer re-configuration during download so that app buffers and net buffer memory spaces are
   handled separately.  This is because for VNI on top of Layer 2 MIPs, the two spaces are in fact separate.
4. Added a "flush cancel" when opening the network interface.

NodeWiz 1.71
------------

1. Jump to 1.7x due to Marketing requirements and changes, mostly cosmetic having to do with Nodeutil release.
2. Support for VNI.  Network interface is opened using VNI unless VNI cannot be found or network interface isn't
   properly configured (some versions of LNS don't support using a L5 MIP as a VNI L5 MIP).


NodeWiz 1.60
------------

This version fixes a bug with hex data entry.  Nodewiz got confused if you entered data as a single digit (without the leading 0).
 
NodeWiz 1.59
------------

This version has the following changes:
1. Fix character echo problem on Windows 98.
2. Allow escaping from certain input prompts back to the main prompt.
3. Fix shelling out to DOS.

NodeWiz 1.58
------------

This version of NodeWiz allows you to get into a device that uses 96 bit authentication.  The key in 
the network interface just has to match that in the device.  The key can be set by going to the node 
zero menu and using the "D" command to set the first 6 bytes of the key in domain 0 and the second 6 
bytes of the key in domain 1.

If you are using a PL3150 SLTA, the firmware automatically supports 96 bit authentication.  If you 
are using a PCLTA, you need to make sure the interface contains the correct image for metering 
(PCL10NLS.NBI).  

NodeWiz FAQ
-----------

***************************
Q: Why does a PL3170 NDL download fail with "Incompatible comm parameters"?
A: The PL3170 boots by default with PL-20N comm parameters.  If you attempt to write comm parameters
for an image built for PL-20A, the compatibility check fails.  You must override the compatibility
checking in this case.
***************************
